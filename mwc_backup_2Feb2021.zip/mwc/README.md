# MWC-JAMstack
 portoflio

_____________________
TERMINAL COMMANDS

<!-- cd ~/Development/mwc -->

gem install unsplash


______________________
code to insert partial

<%= partial "partials/footer" %>


_____________________
.replace_w_contentful

_____________________
button
<button>More <i class="fas fa-chevron-right"></i></button>

_____________________
insert image
<img src="/imgs/gold-coast-1280px.jpg"/>

_____________________
Unsplash random image
https://source.unsplash.com/random/900×700/?people
<img src="https://source.unsplash.com/random/900×700/?people"/>
